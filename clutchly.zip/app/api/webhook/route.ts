import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json(
    { error: "Webhooks not configured yet" },
    { status: 503 }
  );
}
